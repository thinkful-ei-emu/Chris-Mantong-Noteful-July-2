# Paltrows Power Toes

This is a sample project used for education of React Router.

The code is organised into different branches which have progressively more complexity.

## The branches

1. `1-setup`
